
class ques1{

public static void name() {
    


}

}